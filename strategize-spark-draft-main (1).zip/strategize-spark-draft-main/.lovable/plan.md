

## Plan: Intelligent Perspective-Aware Conversation Engine

### Problem
The current conversation engine always asks the same 4 positioning questions sequentially, regardless of what the user already provided. If a user pastes "I'm a founder building an AI startup, want to position as a thought leader with a contrarian take," the system still asks about desired reaction, challenged belief, objective, and voice one by one.

### Design

**1. Add a `UserPerspective` type and store it in session state**

New type in `src/types/content.ts`:
```typescript
export interface UserPerspective {
  name?: string;
  role?: string;        // e.g. "founder", "VP Engineering"
  company?: string;
  topic?: string;
  icp?: string;         // ideal customer profile
  goal?: string;        // "authority" | "engagement" | "lead-gen"
  brandType?: string;   // "founder brand" | "company brand"
}
```

Add `perspective: UserPerspective` to `SessionState` with default `{}`.

**2. Add perspective extraction to the AI analysis step**

Modify the `analyze-document` edge function (or `aiAnalysis.ts` service) to also return inferred perspective signals from the user's input:
- If user says "I'm a CTO at a fintech" → extract `role: "CTO"`, `company: "fintech"`
- If the input mentions "lead generation" → extract `goal: "lead-gen"`
- If user mentions "my personal brand" → extract `brandType: "founder brand"`

This happens silently during the existing Phase 1 analysis — no extra API call.

**3. Make positioning questions conditional (skip what's already known)**

In `useConversationEngine.ts`, after intake confirmation:
- Check what the AI already inferred from the user's input + perspective fields
- Auto-fill strategic position fields that can be derived:
  - `goal` mentioned → skip the "objective" question
  - `brandType` mentioned → skip the "voice" question  
  - Strong contrarian language in source → skip "challengedBelief" question
  - Clear audience signals → audience is already auto-set from seniority selector
- Only ask the remaining unanswered questions
- If everything is inferable, skip straight to angle selection

The transition message adapts: "I've got **2 quick questions**" instead of always saying 4.

**4. Update the positioning questions to match the requested phrasing**

Replace current questions with smarter variants:
- **Objective** → "Are we optimizing for authority, engagement, or lead gen?"
- **Voice** → "Should we prioritize founder brand or company brand?"
- **Desired Reaction** stays similar
- **Challenged Belief** → "Do you want to sound contrarian, analytical, or story-driven?" (this partially overlaps with the angle selection — merge into positioning so the angle phase can auto-resolve too)

**5. Persist perspective in session and use it downstream**

- Pass `perspective` into draft generation so tone/framing reflects it (e.g., founder brand uses "I", company brand uses "We" — already partially done via `voice`)
- Include perspective context in the refinement prompt so the AI maintains consistency
- Store perspective in `useSession` state alongside `strategicPosition`

### Files to Change

| File | Change |
|------|--------|
| `src/types/content.ts` | Add `UserPerspective` interface, add to `SessionState` |
| `src/hooks/useSession.ts` | Add `perspective` state + `updatePerspective` setter |
| `src/hooks/useConversationEngine.ts` | (1) Extract perspective from AI analysis response, (2) Filter positioning questions based on what's already known, (3) Update question wording, (4) Pass perspective to draft generation |
| `src/services/aiAnalysis.ts` | Update AI prompt to also extract perspective signals (role, goal, brand type) from input |
| `supabase/functions/analyze-document/index.ts` | Update system prompt to include perspective extraction in the JSON response |
| `src/pages/Index.tsx` | Wire `updatePerspective` into actions |

### Behavior Examples

**User types:** "I'm a Series B founder in cybersecurity. Want to challenge the idea that compliance = security."
- AI extracts: `role: "founder"`, `topic: "cybersecurity"`, `brandType: "founder brand"`, `challengedBelief: "compliance equals security"`
- System skips: voice question (founder brand), challenged belief question (already stated)
- System asks only: desired reaction + objective (2 questions instead of 4)

**User uploads a PDF with no context:**
- No perspective signals extracted
- All 4 questions asked as normal

**User types:** "Help me build thought leadership around AI governance for enterprise buyers"
- AI extracts: `goal: "authority"`, `icp: "enterprise buyers"`, `topic: "AI governance"`
- System skips: objective question (authority = thought leadership)
- System asks: desired reaction, challenged belief, voice (3 questions)

